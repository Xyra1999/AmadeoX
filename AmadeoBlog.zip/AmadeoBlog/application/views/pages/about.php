<h2><?= $title ?></h2>


</p><h1 style="color:e75480;" align="center"> WELCOME TO MY PIN ME UP PHOTOGRAPHY </h1></p>

</p><h2 style="color:#ffc34d;" align="center"> Stay a MYSTERY; it's BETTER </h2></p>

<h4 <p style="text-align: justify" > Don’t let people really know you, people tend to be-for lack of a better word-attracted to enigmas.
Keeping your cards close to your chest hides your weaknesses and true self, which is quite easier to protect than say, when telling all about yourself.
Quite frankly, you (universal) do not need to know me any more than what I say on a need to know basis. Please stop brown-nosing, people find it rude.
As a mystery, you feel safe shrouded by a lack of knowledge, since others might find you bare with knowledge, and that knowledge is their greatest weapon against you.


Everything is either an opportunity to grow, or an obstacle to keep you from growing. "Sometimes the one thing that you were searching for your entire life was right there in front of you the whole time


Don't express everything. The one who knows about you most has a chance to hurt you most. So its better to always stay a MYSTERY..


“The most beautiful experience we can have is the mysterious. It is the fundamental emotion that stands at the cradle of true art and true science.”

“Every day I remind myself that my inner and outer life are based on the labors of other men, living and dead, and that I must exert myself in order to give in the same measure as I have received and am still receiving.”

“I have never looked upon ease and happiness as ends in themselves -- this critical basis I call the ideal of a pigsty. The ideals that have lighted my way, and time after time have given me new courage to face life cheerfully, have been Kindness, Beauty, and Truth. Without the sense of kinship with men of like mind, without the occupation with the objective world, the eternally unattainable in the field of art and scientific endeavors, life would have seemed empty to me. The trite objects of human efforts -- possessions, outward success, luxury -- have always seemed to me contemptible.”


― Albert Einstein, The World As I See It</p></h4