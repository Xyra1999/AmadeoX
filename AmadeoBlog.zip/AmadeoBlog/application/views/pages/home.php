<h2><?= $title ?></h2>



<h1 style="color: #ffc34d"> H I . . . G O O D       D A Y ! ! ! </h1></p>

<p><h3  style="color:skyblue;"> I'm Xyra Xena Marie Y. Amadeo </h3>

</p><h2 style="text-align: center">  BE YOUR OWN REASON TO SMILE.</p></h2>

<p><h4 style="text-align: center;">  I’m not trying to fit in, I was born to STAND OUT! When you can’t find the sunshine, be the sunshine. Always classy, never trashy, and a little bit sassy. I decide the vibe </p></h4>


<p><h5 style="color:white" style="text-align: justify"> The biggest adventure you can take is to live the life of your dreams. You will never always be motivated, so you must learn to be disciplined. Good things happen. Love is real. We will be okay. </p></h5>

<p><h5 style="text-align: justify"> There so many reasons to be happy. Forget the mistakes; remember the lesson. You don’t have to be perfect to be amazing. See good in all things.</p></h5>
